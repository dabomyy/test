create table product(
	code varchar(12),
	name varchar(12),
	sub1 varchar(1),
	sub2 int,
	sub3 int,
	sub4 int,
	primary key(code)
);