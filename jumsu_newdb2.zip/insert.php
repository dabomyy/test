<?
           session_start();
?>
  <meta charset="utf-8">

<?

include "dbconn.php";// dconn.php 파일을 불러옴

$code = $_POST['code'];
$name = $_POST['name'];
$jum1=$_POST['div'];
$jum2=$_POST['amount'];
$jum3=$_POST['price'];

$jum4 = $jum2 * $jum3;


if ($jum1 == '2')
{
  $jum5 = $jum4-($jum4*0.1);
}else {
  $jum5 = $jum4;
}

     $sql = "insert into product (code,name,sub1,sub2,sub3,sub4) values";
     $sql .= "('$code','$name','$jum1',$jum2,$jum3,$jum5)";
    
     $result = mysqli_query( $connect,$sql);
    mysqli_close($connect);    // DB 접속 끊기
    echo "
    <script>
     location.href = 'pro_list.php';
    </script>
 ";
 
 ?>
  
 </table>
