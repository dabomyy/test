﻿<?
   include "dbconn.php";     

$code = $_GET['code'];

   // 필드 num이 $num 값을 가지는 레코드 삭제
   $sql = "delete from product where code = '$code'"; //'숫자'
  mysqli_query($connect,$sql);

   mysqli_close($connect);

   // score_list.php 로 돌아감 PHP에서는 header() 함수를 활용하여 헤더 정보를 보낼 수가 있으며, 페이지 이동을 위한 코드는 다음과 같다.
   //header('Location: http://www.example.com/');
   Header("Location:pro_list.php"); 
?>

