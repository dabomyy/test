$(function(){ 

  const tagged = {}; //빈방
  $('#gallery img').each(function(){
    const img = this;
    const tags = $(this).data('tags');
    
    if(tags){
      tags.split(',').forEach(function(tagName){
        if (tagged[tagName] == null /*이 없다면*/){
             tagged[tagName] = [];//값이 있으면 
        } 
              tagged[tagName].push(img); //img 집어넣어라
      });
    } 
  });

  $('.first a').on("click",function(){
    $('#button li').removeClass('active');
      $(this).addClass('active')
      $('#gallery img').show();
      return false;
  });

  $.each(tagged, function(tagName){
    $('#button li').on('click', function(){
      $('.first a').removeClass('active');
        const aa = $(this).text(); //aa에 선택 개체의 text 기억시킴

        $(this).addClass('active').siblings().removeClass('active');
      $('#gallery img').hide().filter(tagged[aa]).show();

    });//click종료
  });//.each 종료
});