<?php
  session_start(); //로그인을 유지시켜줌
?>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP</title>
</head>
<body>

  <h3>데이터 입력 하기</h3>
  <form action="insert_1025.php" method="post">
    <table width="720" border="1">
      <tr>
        <td>
          ID : <input type="text" size="6" name="id">
          이름 : <input type="text" size="6" name="name">
          국어 : <input type="text" size="6" name="kor">
          영어 : <input type="text" size="6" name="eng">
          수학 : <input type="text" size="6" name="mat">
        </td>
        <td><input type="submit" value="입력하기"></td>
      </tr>
      <?php
      include "dbconn_1025.php";
      $sql = "select * from addrdb_1025";
      $result = mysqli_query($connect, $sql);
      mysqli_close($connect);  //DB 접속 끊기
      ?>
    </table>
  </form>

</body>
</html>
