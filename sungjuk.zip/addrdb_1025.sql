create table addrdb_1025(
  id varchar(8),
  name varchar(12),
  kor int(3),
  eng int(3),
  mat int(3),
  primary key(id)
);