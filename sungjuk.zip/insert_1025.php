<?php
  session_start();
?>
<meta charset="utf-8">
<?

$id=$_POST['id'];
$name=$_POST['name'];
$kor=$_POST['kor'];
$eng=$_POST['eng'];
$mat=$_POST['mat'];

include "dbconn_1025.php";
$sql="select * from addrdb_1025";
$result=mysqli_query($connect, $sql);
$sql="insert into addrdb_1025(id,name,kor,eng,mat) values";
$sql.="('$id','$name','$kor','$eng','$mat')";

$result=mysqli_query($connect,$sql);
mysqli_close($connect);
echo "
<script>
location.href='addr_ex_1025.php'; 
</script>
";
?>
