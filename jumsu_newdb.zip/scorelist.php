<?
   include "dbconn.php";              

   $mode = $_GET['mode'];
   $name = $_POST['name'];
   $jum1=$_POST['kor'];
   $jum2=$_POST['eng'];
   $jum3=$_POST['mat'];
   $num = $_GET['num'];

 
 
    if ($mode == "insert")                       	 
    {   
          

        $sql = "insert into s_score (name,sub1,sub2,sub3) values";
        $sql .= "('$name',$jum1,$jum2,$jum3)";
 
        $result = mysqli_query( $connect,$sql);
    }
?>
 
 <meta charset="utf-8">
<h3> 성적 입력 하기</h3>

<form action="scorelist.php?mode=insert" method='post'>
<table width="720" border="1">
    <tr>
      <td> 이름 : <input type="text" size="6" name="name"> </td>
      <td> 국어 : <input type="text" size="6" name="kor"> </td>
      <td>영어 : <input type="text" size="6" name="eng"> </td>
      <td> 수학 : <input type="text" size="6" name="mat"> </td>
       <td align="center">
	    <input type="submit" value="입력하기">	
       </td>
    </tr>
 </table>
 </form>
 
<div>
<h3> 성적 출력 하기</h3>  
<p><a href ="scorelist.php?mode=big_first">[이름 내림차순정렬]</a> 
   <a href ="scorelist.php?mode=small_first">[이름 오름차순 정렬]</a></p>
   </div>
 <!-- 제목 표시 시작 -->
 <table width="720" border="1">
 <tr>
 <td>번호</td>
 <td>이름</td>
 <td>국어</td>
 <td>영어</td>
 <td>수학</td>
 <td>DEL</td>
 </tr>
 <!-- 제목 표시 끝 -->
 
 <?

    if ($mode == "big_first")        
       $sql = "select * from s_score order by name desc";
    else if ($mode == "small_first")  
       $sql = "select * from s_score order by name";
    else 
       $sql = "select * from s_score";
 
       $result = mysqli_query( $connect,$sql);
 
    $count = 1;                        // 화면 출력 시 일렬번호
 
 // DB 데이터 출력 시작
    while ($row = mysqli_fetch_array($result))
    {   
      // $avg = round($row['avg'], 1);
 
       $num = $row['num'];
       
       echo "<tr align='center'>
             <td> $count     </td>
       		   <td> $row[name] </td>
             <td> $row[sub1] </td>
             <td> $row[sub2] </td>
             <td> $row[sub3] </td>
       		 <td> <a href='score_del.php?num=$num'>[삭제]</a></td>
	      </tr>
             ";
     
       $count++;
     }
 // DB 데이터 출력 끝

     mysqli_close($connect);                   // DB 접속 끊기
 ?>
  
 </table>
