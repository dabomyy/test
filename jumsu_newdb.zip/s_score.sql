create table s_score (
  num int not null auto_increment, /*자동으로 1씩 증가*/
  name varchar(12),
  sub1 int,
  sub2 int,
  sub3 int,
  primary key(num)
);