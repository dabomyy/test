<?php
  $connect=mysqli_connect("localhost","niryu6","berrych6302!","niryu6") or
  die("SQL server에 연결할 수 없습니다.");
  mysqli_select_db($connect,"niryu6");
?>

