<?php

include "dbconn.php";

$num = $_GET['num'];
$sql = "delete from s_score where num = $num";
mysqli_query($connect,$sql);
mysqli_close($connect);
Header("Location:scorelist.php");
?>
