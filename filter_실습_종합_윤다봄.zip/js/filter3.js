$(function(){
  //data- 로 시작하는 속성들을 하나로 모아 dataset 맵으로 따로 모아 관리
    const $imgs = $('#gallery img');
    const $search = $('#filter-search');
    const cache = [];
  
    $imgs.each(function(){
      cache.push({
        element: this,
        text: this.dataset.tags.trim().toLowerCase(), //한글
        alt: this.alt.trim().toLowerCase()  //영어
      })
    })
  
    //keyup검색창
    function filter(){
      const $bb = $('#button ul li');
      const btnName = $(this).val(); 
      //키보드로 입력한 값을 btnName에 저장
  
      $bb.each(function(){
        const imgAlt = $(this).text();
        const cname = $(this).attr('id'); //영어로도 검색
  
        //초기화면에 설정된 all 빨간색 없어져야 돼서 먼저 지워줌
        if(imgAlt == 'all'){ 
          $('.first a').removeClass('active');
            $('#gallery img').show();
        }
  
        //검색창에 아무것도 입력 안 했을때 all 빨간색 되어야해서
        if(btnName == ''){ 
          $('.first a').addClass('active');
          $('#gallery img').show();
        }
  
        //영어bingsu 혹은 한글 빙수 검색하면 선택개체(this)가 빨간색으로 활성화
        if(btnName == imgAlt || btnName == cname){
          $(this).addClass('active');
        }else{
           $(this).removeClass('active');
        }
      });
  
      //test()
      const query = this.value.trim().toLowerCase();
      cache.forEach(function(img){
        let index;
          let eng = /[a-zA-Z]/;
          if(query){
            if(eng.test(query)){
              index = img.alt.indexOf(query);
            }else{
              index = img.text.indexOf(query);
            }
          }
        img.element.style.display = index === -1 ? 'none' : '';
      })
    }
    $search.on('keyup',filter);
  
    const tagged = {};
    $('#gallery img').each(function(){
      const img = this;
      const tags =$(this).data('tags');
  
      if (tags){
        tags.split(',').forEach(function(tagName){
          if(tagged[tagName] == null){
            tagged[tagName] = [];
          }
          tagged[tagName].push(img);
        });
      }
    });
  
    $('.first a').on('click',function(){
      $('#button li').removeClass('active');
      $(this).addClass('active');
      $('#gallery img').show();
      return false;
    });
  
    $.each(tagged, function(tagName){
      $('#button li').on('click',function(){
        $('.first a').removeClass('active');
        const aa = $(this).text();
        $(this).addClass('active').siblings().removeClass('active');
        $('#gallery img').hide().filter(tagged[aa]).show();
      });
    });
  });