<?php
  session_start();
?>
<meta charset="utf-8">
<?

$id=$_POST['id'];
$name=$_POST['name'];
$addr=$_POST['addr'];

include "dbconn.php";
$sql="select * from addrdb";
$result=mysqli_query($connect, $sql);
$sql="insert into addrdb(id,name,addr) values";
$sql.="('$id','$name','$addr')";

$result=mysqli_query($connect,$sql);
mysqli_close($connect);
echo "
<script>
location.href='addr_ex.php';
</script>
";

?>
