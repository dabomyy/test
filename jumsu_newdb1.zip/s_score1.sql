create table s_score1 (
	num int not null auto_increment,
	name varchar(12),
	sub1 int,
	sub2 int,
	sub3 int,

	primary key(num)
);