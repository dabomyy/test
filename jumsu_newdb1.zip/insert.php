<?
           session_start();
?>
  <meta charset="utf-8">

<?

include "dbconn.php";       // dconn.php 파일을 불러옴

$name = $_POST['name'];
$jum1=$_POST['kor'];
$jum2=$_POST['eng'];
$jum3=$_POST['mat'];

     $sql = "insert into s_score1 (name,sub1,sub2,sub3) values";
     $sql .= "('$name',$jum1,$jum2,$jum3)";

     $result = mysqli_query( $connect,$sql);
 
    mysqli_close($connect);    // DB 접속 끊기
    echo "
    <script>
     location.href = 'scorelist1.php';
    </script>
 ";
 
 ?>
  
 </table>
