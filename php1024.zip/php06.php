<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP</title>
</head>
<body>

<?php
    $a=5;
    echo $a."<Br>";
    $a+=3;
    echo $a."<Br>";
    $a-=4;
    echo $a."<Br>";
    $a*=2;
    echo $a."<Br>";
    $a/=4;
    echo $a."<Br>";
    $a%=2; 
    echo $a."<Br>";

    $a="오렌지";
    $a.=" 주스"; //$a=$a. " 주스"와 동일
    echo $a."<br>";

?>

</body>
</html>