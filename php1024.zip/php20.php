<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP</title>
</head>
<body>

 
<?php

  $score[0]=78;
  $score[1]=83;
  $score[2]=97;
  $score[3]=88;
  $score[4]=78;

  $sum = 0;
  for ($a=0; $a<count($score); $a++)
  {
    $sum = $sum + $score[$a];
  }
  $avg = $sum/5;
  echo("과목 점수 : $score[0], $score[1], $score[2], $score[3], $score[4]<br>");
  echo("합계 : $sum, 평균 : $avg <br>");

?>

</body>
</html>
