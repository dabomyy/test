<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP</title>
</head>
<body>

 
<?php

 $tel = "010-2777-3333";
 $num_tel = strlen($tel);
 echo "strlen() 함수 사용 : $num_tel<br>";
 $tel1 = substr($tel,0,3); //0번째 글자로부터 3개의 글자
 $tel2 = substr($tel,4,4);  //4번째 글자로부터 4개의 글자
 $tel3 = substr($tel,9,4); //9번째 글자로부터 4개의 글자
 echo "substr() 함수 사용 : $tel1 $tel2 $tel3<Br>";

 $phone = explode("-",$tel);
 echo "explode() 함수 사용 : $phone[0] $phone[1] $phone[2]<br>";
?>

</body>
</html>
