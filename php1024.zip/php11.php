<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP</title>
</head>
<body>
<?php
   //90이상이면 점수 A 80이상이면 B 70이상이면 C 60이상이면 D 아니면 F 
  $a=85;

  if ($a >= 90)
    echo "$a ==> A";

  elseif ($a >= 80)
    echo "$a ==> B";

  elseif ($a >= 70)
    echo "$a ==> C";

  elseif ($a >= 60)
    echo "$a ==> D";

  else 
    echo "$a ==> F";
    
?>
</body>
</html>