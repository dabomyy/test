<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP</title>
</head>
<body>
<?php
  //조건에 맞지 않아도 무조건 한번 실행

  $i=100;

  do 
  {
    echo $i."<br>";
  }
  while ($i <=10)

    
?>
</body>
</html>