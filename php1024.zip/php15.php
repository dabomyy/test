<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP</title>
</head>
<body>

<?php

  $sum=0;
  for($a=1; $a<=10; $a++)
  {
    $sum += $a;
  }

  echo("1에서 10까지 자연수의 합은 $sum 입니다.<br>");

?>

</body>
</html>
