<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP</title>
</head>
<body>

<?php
    
    $besu=5;
    $num=15;

    if ($num % $besu == 0)
    {
        echo "$num 은(는) $besu 의 배수다.";
    }
    else
    {
        echo "$num 은(는) $besu 의 배수가 아니다.";
    }
    
?>

</body>
</html>