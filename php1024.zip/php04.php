<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP</title>
</head>
<body>

<?php
 $a=7;
 $b=8;

 $a++;
 $b--;

 $b=$a*$b+2; //
 $c=$a+$b;

 echo "a:$a, b:$b, c:$c<br>";
?>

</body>
</html>